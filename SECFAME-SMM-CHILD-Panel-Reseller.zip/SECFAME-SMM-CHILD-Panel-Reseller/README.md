**

## SECFAME - SMM Panel Child

*SMM = Social Media Marketing.*

> What is this code?

 + Sell  Followers, Views and Much more using API From (https://secfame.com).

## Do you wanna try?

*Access: http://secfame.com.com*

    Email: admin@admin.com
    Password: adminadmin

## How to install?
**First:**

    Upload smm Folder with public_html

![enter image description here](https://secfame.com.com/)

**Second:**

    Create a database and upload database.sql from database > database.sql
Third:

    Go to smm > config > database.php and setup your database. 👇
![enter image description here](https://secfame.com/)

*Now go to your domain and Start Using.*

**

## USAGE POLICY

**

> You can use this script to resell SMM Services using API's
> 
You don't have to use [secfame.com](https://secfame.com) API's you can choose your better option.

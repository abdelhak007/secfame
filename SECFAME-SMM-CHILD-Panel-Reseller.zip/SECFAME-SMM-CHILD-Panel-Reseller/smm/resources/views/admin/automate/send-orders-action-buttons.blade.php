<button class="send-api btn btn-primary btn-sm" data-id="{{$id}}" data-package_id="{{$package_id}}">
    <span>@lang('buttons.send')</span>
</button>
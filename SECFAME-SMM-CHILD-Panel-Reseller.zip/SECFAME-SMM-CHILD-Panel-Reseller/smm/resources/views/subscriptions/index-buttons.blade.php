<div class="btn-group">
    <a href="{{ url('/subscriptions/'. $id) }}"
       title="View orders"
       class="btn btn-xs btn-inverse">
        <span class="glyphicon glyphicon-list-alt"></span>
    </a>
</div>
<?php
return [
    'ticket_submitted_subject' => 'يتم إنشاء تذكرة دعم جديدة.',
    'ticket_message_subject' => 'لقد تلقيت رسالة جديدة.',
    'message' => 'رسالة',
    'description' => 'وصف',
    'subject' => 'موضوع',
    'ticket_id' => 'معرف التذكرة',
    'user' => 'المستعمل',
    'system_status_report' => 'تقرير حالة النظام',
    'orders' => 'أوامر',
    'tickets' => 'تذاكر',
    'users' => 'المستخدمين',
    'new' => 'الجديد',
    'total' => 'مجموع',
    'today' => 'اليوم',
    'this_month' => 'هذا الشهر',
    'lifetime' => 'أوقات الحياة',

];
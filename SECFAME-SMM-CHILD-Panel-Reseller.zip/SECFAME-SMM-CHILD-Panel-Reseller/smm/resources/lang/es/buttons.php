<?php

return [

    'login' => 'Iniciar sesión',
    'update' => 'Actualizar',
    'create_new' => 'Crear nuevo',
    'create' => 'Crear',
    'send' => 'Enviar',
    'proceed' => 'Proceder',
    'pay' => 'Paga',
    'new_order' => 'Nuevo orden',
    'see_packages' => 'Ver Paquetes',
    'place_order' => 'Realizar pedido',
    'create_new_ticket' => 'Crear nuevo ticket',
    'register' => 'Registro',
    'generate' => 'Generar',
    'send_password_reset' => 'Enviar contraseña Restablecer enlace',
    'reset_password' => 'Restablecer la contraseña',
    'add_new' => 'Añadir nuevo',
    'order_now' => 'Ordenar ahora',
    'get_status' => 'Obtener estado',
    'regenerate' => 'Regenerado',
    'add' => 'Añadir',
    'change_reseller' => 'Cambiar Revendedor',
];

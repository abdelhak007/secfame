<?php

return [

    'login' => 'Se connecter',
    'update' => 'Mettre à jour',
    'create_new' => 'Créer un nouveau',
    'create' => 'Créer',
    'send' => 'Envoyer',
    'proceed' => 'Procéder',
    'pay' => 'Payer',
    'new_order' => 'Nouvelle commande',
    'see_packages' => 'Voir les paquetages',
    'place_order' => 'Passer la commande',
    'create_new_ticket' => 'Créer un nouveau ticket',
    'register' => 'S\'inscrire',
    'generate' => 'Générer',
    'send_password_reset' => 'Envoyer le lien de réinitialisation du mot de passe',
    'reset_password' => 'Réinitialiser le mot de passe',
    'add_new' => 'Ajouter un nouveau',
    'order_now' => 'Commander maintenant',
    'get_status' => 'Obtenir le statut',
    'regenerate' => 'Régénérer',
    'add' => 'Ajouter',
    'change_reseller' => 'Change Revendeur',

];

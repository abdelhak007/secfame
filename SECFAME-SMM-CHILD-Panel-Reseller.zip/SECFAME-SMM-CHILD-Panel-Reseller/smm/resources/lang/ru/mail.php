<?php
return [
    'ticket_submitted_subject' => 'Создается новый билет поддержки.',
    'ticket_message_subject' => 'Вы получили новое сообщение.',
    'message' => 'Сообщение',
    'description' => 'Описание',
    'subject' => 'Предмет',
    'ticket_id' => 'Идентификатор билета',
    'user' => 'пользователь',
    'system_status_report' => 'Отчет о состоянии системы',
    'orders' => 'заказы',
    'tickets' => 'Билеты',
    'users' => 'пользователей',
    'new' => 'новый',
    'total' => 'Всего',
    'today' => 'Cегодня',
    'this_month' => 'Этот месяц',
    'lifetime' => 'Продолжительность жизни',

];
<?php
return [
    'ticket_submitted_subject' => 'Ein neues Support-Ticket wird erstellt.',
    'ticket_message_subject' => 'Sie haben eine neue Nachricht erhalten.',
    'message' => 'Nachricht',
    'description' => 'Beschreibung',
    'subject' => 'Fach',
    'ticket_id' => 'Ticket Nummer',
    'user' => 'Benutzer',
    'system_status_report' => 'Systemstatusbericht',
    'orders' => 'Aufträge',
    'tickets' => 'Tickets',
    'users' => 'Benutzer',
    'new' => 'Neu',
    'total' => 'Gesamt',
    'today' => 'Heute',
    'this_month' => 'Diesen Monat',
    'lifetime' => 'Lebenszeit',

];
<?php
return [
    'ticket_submitted_subject' => 'A new support ticket is created.',
    'ticket_message_subject' => 'You have received a new message.',
    'message' => 'Message',
    'description' => 'Description',
    'subject' => 'Subject',
    'ticket_id' => 'TicketID',
    'user' => 'User',
    'system_status_report' => 'System Status Report',
    'orders' => 'Orders',
    'tickets' => 'Tickets',
    'users' => 'Users',
    'new' => 'New',
    'total' => 'Total',
    'today' => 'Today',
    'this_month' => 'This Month',
    'lifetime' => 'Lifetime',

];
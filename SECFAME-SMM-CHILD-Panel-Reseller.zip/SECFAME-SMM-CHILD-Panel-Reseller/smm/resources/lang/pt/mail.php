<?php
return [
    'ticket_submitted_subject' => 'É criado um novo ticket de suporte.',
    'ticket_message_subject' => 'Você recebeu uma nova mensagem.',
    'message' => 'mensagem',
    'description' => 'Descrição',
    'subject' => 'Sujeito',
    'ticket_id' => 'TicketID',
    'user' => 'Do utilizador',
    'system_status_report' => 'Relatório de Status do Sistema',
    'orders' => 'Pedidos',
    'tickets' => 'Ingressos',
    'users' => 'Comercial',
    'new' => 'Novo',
    'total' => 'Total',
    'today' => 'Hoje',
    'this_month' => 'Este mês',
    'lifetime' => 'Tempo de vida',

];